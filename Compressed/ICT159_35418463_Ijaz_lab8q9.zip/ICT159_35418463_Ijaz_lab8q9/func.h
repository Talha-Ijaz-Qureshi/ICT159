int getNvalue();
int readStr(int n, char *inputArr);
int isVowel(char c);
int vowelCount(int n, char *inputArr);
char* returnVowels(char *inputArr, int n, int vowelN);
void displayVowelsInfo(int vowelN, char *vowelArr);
void printVowels(char *vowelArr);