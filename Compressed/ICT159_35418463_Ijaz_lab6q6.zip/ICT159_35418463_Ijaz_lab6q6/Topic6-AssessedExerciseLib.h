#ifndef Topic6_AssessedExerciseLib_c
#define Topic6_AssessedExerciseLib_c

int max(int x, int y, int z);
int min(int x, int y, int z);
float average(int x, int y, int z);
int maxMinDifference(int x, int y, int z);
float maxAvgDifference(int x, int y, int z);
int absoluteMinValue(int x, int y, int z);
int checkType(int x);

#endif
