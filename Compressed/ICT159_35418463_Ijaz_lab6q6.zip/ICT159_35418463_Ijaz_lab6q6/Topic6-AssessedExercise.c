#include <stdio.h>
#include "Topic6-AssessedExerciseLib.h"

int main() {
    int a, b, c, typeCheck;
    printf("Enter 3 numbers\n");
    typeCheck = scanf("%d", &a);
    typeCheck = scanf("%d", &b);
    typeCheck = scanf("%d", &c);
    getchar();

    if (checkType(typeCheck) == 1) {
        printf("\nMaximum: %d\n", max(a, b, c));
        printf("Minimum: %d\n", min(a, b, c));
        printf("Average: %.3f\n", average(a, b, c));
        printf("Difference of Max and Min: %d\n", maxMinDifference(a, b, c));
        printf("Difference of Max and Average: %.3f\n", maxAvgDifference(a, b, c));
        printf("Absolute Minimum Value: %d\n", absoluteMinValue(a, b, c));
    } 

    getchar();
    return 0; 
}
