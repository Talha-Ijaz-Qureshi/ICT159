#include "Topic6-AssessedExerciseLib.h"
#include <stdio.h>
int max(int x, int y, int z) {
    if (x > y && x > z) {
        return x;
    } else if (y > z) {
        return y;
    } else {
        return z;
    }
}

int min(int x, int y, int z) {
    if (x < y && x < z) {
        return x;
    } else if (y < z) {
        return y;
    } else {
        return z;
    }
}

float average(int x, int y, int z) {
    return (float)(x + y + z) / 3;
}

int maxMinDifference(int x, int y, int z) {
    int minValue = min(x, y, z);
    int maxValue = max(x, y, z);
    return maxValue - minValue;
}

float maxAvgDifference(int x, int y, int z) {
    float avgValue = average(x, y, z);
    int maxValue = max(x, y, z);
    return (maxValue - avgValue);
}

int absoluteMinValue(int x, int y, int z) {
    int minValue = min(x, y, z);
    if (minValue < 0) {
        return -minValue;
    } else {
        return minValue;
    }
}

int checkType(int x) {
    if (x == 0)
    {
        printf("Enter a number only\n");
        while (getchar() != '\n');
        return 0;
    }
    else {
        return 1;
    }
}