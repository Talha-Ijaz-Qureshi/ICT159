int ccySelect();
int readAmount();
int validCheck(int input, int ccy);
void calcCoins(int input, int ccy, int coinCount[]);
void displayCoins(int coinCount[], int ccy);
int proceedPrgm();